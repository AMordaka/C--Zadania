﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplikacja
{
    interface InterfaceWysokosc
    {
        double Wysokosc { get; set; }
    }
}
