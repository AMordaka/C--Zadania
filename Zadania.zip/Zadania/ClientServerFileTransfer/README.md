# ClientServerFileTransfer
4.	Napisać program w architekturze klient-serwer pozwalający przesyłać pliki przez Internet. Wykorzystać mechanizm serializacji. Serwer napisać wielowątkowo.